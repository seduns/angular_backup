import { CommonModule } from '@angular/common';
import { Component, inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { GoogleGenerativeAI } from '@google/generative-ai';
import { GeminiService } from './gemini.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Context } from 'html2canvas/dist/types/core/context';

@Component({
  selector: 'app-test-entity',
  standalone: true,
  imports: [FormsModule,CommonModule],
  templateUrl: './test-entity.component.html',
  styleUrls: ['./test-entity.component.scss']
})
export class TestEntityComponent implements OnInit {

  chatHistory : {prompt: string, response: string}[] = [];
  showChat: boolean = false;

  ngOnInit(): void {
  }

  openChat() {  
    this.showChat = !this.showChat;
  }

  closeChat() { 
    this.showChat = !this.showChat
  }

      title = 'gemini-test';
      prompt: string = '';
      response: string = '';  
      loading: boolean = false;
      timeResponse: Date;
      timeHistory: { timeResponse : Date }[] = [];

      chatStore: string[] = [];
      
      sendingState: boolean = false;
      
      geminiService: GeminiService = inject(GeminiService);
      http: HttpClient = inject(HttpClient); 
    
      async sendData() {
        this.response = '';
        this.loading = true;
    
        // Record the current time
        const currentTime = new Date();
        this.timeHistory.push({ timeResponse: currentTime });
    
        // Add user's prompt to chat history with an empty response initially
        const chatEntry = { prompt: this.prompt, response: '', sending: true };
        this.chatHistory.push(chatEntry);
        
        // console.log(this.chatHistory);

        const userPrompt = this.prompt; // Save the prompt to use later
        this.prompt = ''; // Clear input field immediately

    
        try {
            // Fetch context from API for the current prompt
            const context = await this.http
                .get('http://localhost:44305/api/scraper/notes', { responseType: 'text' })
                .toPromise();
    
            if (userPrompt) {
                // Generate AI response for the current prompt
                const generatedResponse = await this.geminiService.generateText(
                    `${context} \nUser's question: ${userPrompt} \nAnswer:`
                );

                // console.log('AI answer 2: ', this.geminiService.generateText( `${context}  \nUser's question: ${userPrompt} \nAnswer:`));
    
                // Handle AI response
                chatEntry.response =
                    generatedResponse && !generatedResponse.toLowerCase().includes('sorry')
                        ? generatedResponse
                        : "Sorry, I couldn't generate an answer.";
            }
    
            // Regenerate responses for previous chats (optional, depending on your use case)
            for (const chat of this.chatHistory) {
                if (!chat.response) {
                    const previousResponse = await this.geminiService.generateText(
                        `${context} \nUser's question: ${chat.prompt} \nAnswer:`
                    );
    
                    chat.response =
                        previousResponse && !previousResponse.toLowerCase().includes('sorry')
                            ? previousResponse
                            : "Sorry, I couldn't generate an answer.";

                }
            }
        } catch (error) {
            console.error('Error fetching context or generating text:', error);
            chatEntry.response = 'Error generating response. Please try again.';
        } finally {
            this.loading = false;
            chatEntry.sending = false;
        }
    }

      getTimeAgo(time: Date): string {
        if (!time) return '';
        
        const now = new Date();
        const diffMs = now.getTime() - time.getTime();
        const diffSeconds = Math.floor(diffMs / 1000);
        const diffMinutes = Math.floor(diffSeconds / 60);
        const diffHours = Math.floor(diffMinutes / 60);
        const diffDays = Math.floor(diffHours / 24);
      
        if (diffSeconds < 60) {
          
          return diffSeconds === 1 ? 'just now' : ` just now`;
        } else if (diffMinutes < 60) {
          return diffMinutes === 1 ? 'a minute ago' : `${diffMinutes} minutes ago`;
        } else if (diffHours < 24) {
          return diffHours === 1 ? 'an hour ago' : `${diffHours} hours ago`;
        } else {
          return diffDays === 1 ? 'a day ago' : `${diffDays} days ago`;
        }
      }
      
      
      
      
  
      formatText(text: string): string {
        return text.replace(/\*/g, ''); // The `/\*/g` ensures all `*` are replaced
      }

      formatTextWithParagraphs(text: string): string {
        // Split the text by newline characters (\n)
        const lines = text.split('\n');
    
        // Process each line
        const formattedText = lines
            .map(line => {
                // Replace **text** with <b>text</b>
                let formattedLine = line.replace(/\*\*(.*?)\*\*/g, '<b>$1</b>');
    
                // Remove single * from text
                formattedLine = formattedLine.replace(/\*(.*?)\*/g, '$1');
    
                // Wrap the line with <p> tags if it contains text
                return line.trim() ? `<p>${formattedLine.trim()}</p>` : '';
            })
            .join(''); // Join all lines back into a single string
    
        return formattedText;
    }
    
      
      
      

}
